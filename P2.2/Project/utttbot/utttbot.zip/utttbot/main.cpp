// main.cpp
// Aswin van Woudenberg

#include "utttbot.h"

int main() {
	UTTTBot bot;
	bot.run();
	
	return 0;
}


