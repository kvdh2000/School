// utttbot.cpp
// Aswin van Woudenberg

#include "utttbot.h"

#include <iostream>
#include <sstream>

using namespace std;

array<int, 9> scores = { 0,0,0,0,0,0,0,0,0 };
int activemb = 0;

int UTTTBot::getX(int i)
{
	if (i < 3)
		return 0;
	if (i < 6)
		return 1;
	else
		return 2;
}

int UTTTBot::getY(int i)
{
	/*if (i == 0 || i == 3 || i == 6)
		return 0;
	if (i ==1 || i == 4 || i == 7)
		return 1;
	else
		return 2;*/

	if (i == 0 || i == 1 || i == 2)
		return 0;
	if (i == 3 || i == 4 || i == 5)
		return 1;
	else
		return 2;
}

void UTTTBot::findAMB(State &board)
{
	for (int x = 0; x < 9; x++)
	{
		for (int y = 0; y < 9; y++)
		{
			if (board.board[x][y] == Player::Active)
			{
				foundit(x, y);
			}
		}
	}
}

void UTTTBot::foundit(int x, int y)
{
		
}

void UTTTBot::run() 
{
	std::string line;

	while (std::getline(std::cin, line)) 
	{
		std::vector<std::string> command = split(line, ' ');

		if (command[0] == "settings") 
		{
			setting(command[1], command[2]);
		} 

		else if (command[0] == "update" && command[1] == "game") 
		{
			update(command[2], command[3]);
		} 

		else if (command[0] == "action" && command[1] == "move") 
		{
			move(std::stoi(command[2]));
		} 

		else 
		{
			std::cerr << "Unknown command: " << line << std::endl;
		}
	}
}


void UTTTBot::mcUpdateScores(State &trialboard, Player &winner)
{
	array<int, 9> subscores = { 0, 0, 0, 0, 0, 0, 0, 0, 0 };

	for (int i = 0; i < 9; i++)
	{
		int x = getX(i);
		int y = getY(i);

		if (winner == Player::X)
		{
			if (trialboard.macroboard[x][y] == Player::X)
			{
				subscores[i]++;
			}

			if (trialboard.macroboard[x][y] == Player::O)
			{
				subscores[i]--;
			}
		}

		if (winner == Player::O)
		{
			if (trialboard.macroboard[x][y] == Player::X)
			{
				subscores[i]--;
			}

			if (trialboard.macroboard[x][y] == Player::O)
			{
				subscores[i]++;
			}
		}
	}


	for (int i = 0; i < 9; i++)
	{
		scores[i] = scores[i] + subscores[i];
	}
}

State UTTTBot::mcTrial(const State &board)
{
	State trialboard = board;
	
	Player winner;

	vector<Move> moves = getMoves(trialboard);

	while (moves.size() != 0)
	{
		trialboard = doMove(trialboard, moves[(rand() % moves.size())]);
		moves = getMoves(trialboard);
	}

	winner = getWinner(trialboard);

	mcUpdateScores(trialboard, winner);


	return board;
}

Move UTTTBot::getBestMove(State &board)
{
	int highest = -999999;

	int dx = -99999;
	int dy = -99999;
	
	
	for (int i = 0; i < 9; i++)
	{
		int x = getX(i);
		int y = getY(i);

		if (false)//scores[i] > highest && board.macroboard[x][y] == Player::Active)
		{
			highest = scores[i];
			dx = x;
			dy = y;
		}

		
		if (board.board[x][y] == Player::Active)
		{
			if (scores[i] > highest)
			{
				highest = scores[i];
				dx = x;
				dy = y;
			}
		}
		if (board.board[x + 3][y] == Player::Active)
		{
			if (scores[i] > highest)
			{
				highest = scores[i];
				dx = x + 3;
				dy = y;
			}
		}
		if (board.board[x + 6][y] == Player::Active)
		{
			if (scores[i] > highest)
			{
				highest = scores[i];
				dx = x + 6;
				dy = y;
			}
		}
		if (board.board[x][y + 3] == Player::Active)
		{
			if (scores[i] > highest)
			{
				highest = scores[i];
				dx = x;
				dy = y + 3;
			}
		}
		if (board.board[x + 3][y + 3] == Player::Active)
		{
			if (scores[i] > highest)
			{
				highest = scores[i];
				dx = x + 3;
				dy = y + 3;
			}
		}
		if (board.board[x + 6][y + 3] == Player::Active)
		{
			if (scores[i] > highest)
			{
				highest = scores[i];
				dx = x + 6;
				dy = y + 3;
			}
		}
		if (board.board[x][y + 6] == Player::Active)
		{
			if (scores[i] > highest)
			{
				highest = scores[i];
				dx = x;
				dy = y + 6;
			}
		}
		if (board.board[x + 3][y + 6] == Player::Active)
		{
			if (scores[i] > highest)
			{
				highest = scores[i];
				dx = x + 3;
				dy = y + 6;
			}
		}
		if (board.board[x + 6][y + 6] == Player::Active)
		{
			if (scores[i] > highest)
			{
				highest = scores[i];
				dx = x + 6;
				dy = y + 6;
			}
		}
		
	}

	return { dx, dy };
}

Move UTTTBot::mcMove(State &board)
{
	scores = { 0,0,0,0,0,0,0,0,0 };

	//findAMB(board);

	for (int i = 0; i < 10000; i++)
	{
		board = mcTrial(board);
	}

	return getBestMove(board);
}

void UTTTBot::move(int timeout) 
{
	// Do something more intelligent here than return a random move
	//vector<Move> moves = getMoves(state);
	//moves.push_back(mcMove(state));
	Move theMove = mcMove(state);
	//std::cout << "place_disc " << *(moves.end() - 1) << std::endl;
	std::cout << "place_disc " << theMove << std::endl;
}

void UTTTBot::update(std::string &key, std::string &value) {
	if (key == "round") {
		round = std::stoi(value);
	} else if (key == "field") {
		int row = 0;
		int col = 0;
		std::vector<std::string> fields = split(value, ',');
		for (std::string &field : fields) {
			if (field == "0") {
				state.board[row][col] = Player::X; 
			} else if (field == "1") {
				state.board[row][col] = Player::O;
			} else {
				state.board[row][col] = Player::None;
			}
			col++;
			if (col == 9) {
				row++; 
				col = 0;
			}
		}
	} else if (key == "macroboard") {
		int row = 0;
		int col = 0;
		std::vector<std::string> fields = split(value, ',');
		for (std::string &field : fields) {
			if (field == "-1") {
				state.macroboard[row][col] = Player::Active;
			} else if (field == "0") {
				state.macroboard[row][col] = Player::X;
			} else if (field == "1") {
				state.macroboard[row][col] = Player::O;
			} else {
				state.macroboard[row][col] = Player::None;
			}
			col++;
			if (col == 3) {
				row++;
				col = 0;
			}
		}
	}
}

void UTTTBot::setting(std::string &key, std::string &value) {
	if (key == "timebank") {
		timebank = std::stoi(value);
	} else if (key == "time_per_move") {
		time_per_move = std::stoi(value);
	} else if (key == "player_names") {
		std::vector<std::string> names = split(value, ',');
		player_names[0] = names[0];
		player_names[1] = names[1];
	} else if (key == "your_bot") {
		your_bot = value;
	} else if (key == "your_botid") {
		your_botid = std::stoi(value);
	}
}

std::vector<std::string> UTTTBot::split(const std::string &s, char delim) {
	std::vector<std::string> elems;
	std::stringstream ss(s);
	std::string item;
	while (std::getline(ss, item, delim)) {
		elems.push_back(item);
	}
	return elems;
}

